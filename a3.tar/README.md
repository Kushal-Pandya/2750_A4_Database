CIS 2750
A3
Author: Kushal Pandya
Due Date: March 10 2017 Extended to: Sunday March 19


LIMITATIONS OR THINGS THAT DONT WORK
-----------------------

C Program
- tags that are not specified in assignment will not work
- most default attributes will not work, only specified attributes will convert

Viewer
- if user doesn't have access to a stream and selects "view", then the error message will show up as one of the radio button options
- Page Up/Page Down buttons can sometimes have undefined behavior and may act strangely



